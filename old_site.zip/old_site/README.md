1. change_config.yml for sidebar
2. change _pages/about.md for index
