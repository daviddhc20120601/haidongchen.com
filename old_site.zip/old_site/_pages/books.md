---
title: "books"
excerpt: "books from me"
sitemap: true
permalink: /books/
---

here are the books from me

## Medical and Health Care
* [GxP Cloud Adoption Guidelines Whitepaper](https://resource.alibabacloud.com/whitepaper/gxp-cloud-adoption-guidelines-whitepaper_7104)

![img](https://img-intl.alicdn.com/whitepaper/wp_image_file-2023111716291900001.jpg)

